<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Créer une voiture </title>
    </head>
    <body>
        <h1>Créer une voiture</h1>
        <form method="get" action="routeur.php?action=created">
            <fieldset>
                <legend>Mon formulaire :</legend>
                <p>
                    <label for="immat_id">Immatriculation</label> :
                    <input type="text" placeholder="256AB34" name="immatriculation" id="immat_id" required/>
                </p>
                <p>
                    <label for="marque_id">Marque</label> :
                    <input type="text" placeholder="Peugeot" name="marque" id="marque_id" required/>
                </p>
                <p>
                    <label for="couleur_id">Couleur</label> :
                    <input type="text" placeholder="Blanc" name="couleur" id="couleur_id" required/>
                </p>
                <p>
                    <label for="nbSiege_id">Nombre de siège</label> :
                    <input type="text" placeholder="5" name="nbSiege" id="nbSiege_id" required/>
                </p>
                <input type='hidden' name='action' value='created'>
                <p>
                    <input type="submit" value="Envoyer" />
                </p>
            </fieldset>
        </form>
        <p><a href="ControllerVoiture.php?action=readAll">Retour à la liste des voitures</a></p>
    </body>
</html>

