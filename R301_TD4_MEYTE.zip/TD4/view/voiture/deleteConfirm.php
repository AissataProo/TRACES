<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8" />
    <title> Êtes vous sur de ce choix ?> </title> 
</head>
<body>
    <h1> Êtes vous sûr ? </h1>
    <h3> De vouloir supprimer</h3>
    <form method="get" action="routeur.php?action=deleted">
        <p> Voiture possédant l'immatriculation : <?php echo $voitures->getImmatriculation(); ?> </p>
        <input type='hidden' name='immat' value='<?php echo $voitures->getImmatriculation(); ?>'>
        <input type='hidden' name='action' value='deleted'>
        <p>
            <input type="submit" value="Envoyer" />
        </p>
    </form>
    <p><a href="routeur.php?action=readAll">Retour à la liste des voitures</a></p>
</body>
</html>