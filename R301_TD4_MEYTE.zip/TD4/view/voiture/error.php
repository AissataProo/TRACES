<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Erreur</title>
    </head>
    <body>
        <h1>Erreur</h1>
        <?php
        echo '<p> Ne trouve pas de voiture correspondant à l\'immatriculation ' . $immat . '</p>';
        ?>
    </body>
</html>