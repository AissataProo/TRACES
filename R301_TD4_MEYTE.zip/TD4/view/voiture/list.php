<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Liste des voitures</title>
    </head>
    <body>
        <h1>Liste des voitures</h1>
        <?php
        foreach ($voitures as $voiture) {
            echo '<p> Voiture avec l\'immatriculation ' . $voiture->getImmatriculation() . '</p>';
            echo '<input type="button" value="Détail" onclick="window.location.href=\'routeur.php?action=read&immat=' . $voiture->getImmatriculation() . '\';">';
            echo '<input type="button" value="Supprimer" onclick="window.location.href=\'routeur.php?action=deleteConfirm&immat=' . $voiture->getImmatriculation() . '\';">';
        }
        ?>
    </body>
</html>
