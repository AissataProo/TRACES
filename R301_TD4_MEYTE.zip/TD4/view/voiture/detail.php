<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Détails de la voiture</title>
    </head>
    <body>
        <h1>Détails de la voiture</h1>
        <p>Immatriculation : <?php echo $voitures->getImmatriculation(); ?></p>
        <p>Marque : <?php echo $voitures->getMarque(); ?></p>
        <p>Couleur : <?php echo $voitures->getCouleur(); ?></p>
        <p>Nombre de sièges : <?php echo $voitures->getNbSieges(); ?></p>
    </body>
</html>