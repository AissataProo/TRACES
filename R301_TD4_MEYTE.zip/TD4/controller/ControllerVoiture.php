<?php
require_once '../model/ModelVoiture.php'; // chargement du modèle

class ControllerVoiture{
    public static function readAll() : void{
        $voitures = ModelVoiture::getVoitures();
        self::afficheVue('voiture/list.php', ['voitures' => $voitures]);
    }

    public static function read() : void{
        $immat = $_GET['immat'];
        if (ModelVoiture::getVoitureParImmat($immat) == null) {
            self::afficheVue('voiture/error.php', ['immat' => $immat]);
        }
        else{
            $voitures = ModelVoiture::getVoitureParImmat($immat);
            self::afficheVue('voiture/detail.php', ['voitures' => $voitures]);
        }
    }

    public static function afficheVue(string $cheminVue, array $parametres = []) : void {
        extract($parametres);
        require "../view/$cheminVue";
    }

    public static function create() : void{
        self::afficheVue('voiture/create.php');
    }

    public static function created() : void{
        $immat = $_GET['immatriculation'];
        $marque = $_GET['marque'];
        $couleur = $_GET['couleur'];
        $nbSieges = $_GET['nbSiege'];
        $voiture = new ModelVoiture($immat, $marque, $couleur, $nbSieges);
        $voiture->sauvegarder();
        self::readAll();
    }

    public static function deleteConfirm() : void{
        $immat = $_GET['immat'];
        $voiture = ModelVoiture::getVoitureParImmat($immat);
        self::afficheVue('voiture/deleteConfirm.php', ['voitures' => $voiture]);
    }

    public static function deleted() : void{
        $immat = $_GET['immat'];
        $voiture = ModelVoiture::getVoitureParImmat($immat);
        $voiture->supprimer();
        self::readAll();
    }

}
