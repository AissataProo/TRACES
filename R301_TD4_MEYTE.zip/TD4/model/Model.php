<?php
// On inclut le fichier Conf.php pour pouvoir utiliser la classe Conf
require_once '../config/Conf.php';

// Déclaration de la classe Model
class Model {
    // Attribut privé $pdo pour stocker l'objet PDO
    private $pdo;
    // Attribut privé statique $instance pour stocker l'unique instance de la classe Model
    private static $instance = null;

    private function __construct() {
        $hostname = Conf::getHostname();
        $databaseName = Conf::getDatabase();
        $login = Conf::getLogin();
        $password = Conf::getPassword();

        // Connexion à la base de données avec les options recommandées pour PDO
        $options = array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8");
        $this->pdo = new PDO("mysql:host=$hostname;dbname=$databaseName", $login, $password, $options);

        // Activation du mode d'affichage des erreurs et du lancement d'exception en cas d'erreur
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    // Accesseur (getter) statique pour l'attribut $pdo
    public static function getPdo() {
        // On retourne l'objet PDO stocké dans l'unique instance de la classe Model
        return static::getInstance()->pdo;
    }

    // Méthode privée statique pour obtenir l'unique instance de la classe Model
    private static function getInstance() {
        // Si aucune instance n'a été créée, on en crée une nouvelle
        if (is_null(static::$instance))
            static::$instance = new Model();
        // On retourne l'unique instance de la classe Model
        return static::$instance;
    }
}
?>
