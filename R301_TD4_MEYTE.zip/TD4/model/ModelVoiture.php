<?php
declare(strict_types=1);
require_once 'Model.php';

class ModelVoiture {
    private string $immatriculation;
    private string $marque;
    private string $couleur;
    private int $nbSieges; // Nombre de places assises

    // Getters
    public function getMarque(): string {
        return $this->marque;
    }

    public function getCouleur(): string {
        return $this->couleur;
    }

    public function getImmatriculation(): string {
        return $this->immatriculation;
    }

    public function getNbSieges(): int {
        return $this->nbSieges;
    }

    // Setters
    public function setMarque(string $marque): void {
        $this->marque = $marque;
    }

    public function setCouleur(string $couleur): void {
        $this->couleur = $couleur;
    }

    public function setImmatriculation(string $immatriculation): void {
        // Limiter l'immatriculation à 8 caractères
        if (strlen($immatriculation) > 8) {
            $immatriculation = substr($immatriculation, 0, 8);
        }
        $this->immatriculation = $immatriculation;
    }

    public function setNbSieges(int $nbSieges): void {
        $this->nbSieges = $nbSieges;
    }

    // Constructeur
    public function __construct(string $immatriculation, string $marque, string $couleur, int $nbSieges) {
        $this->setImmatriculation($immatriculation);
        $this->setMarque($marque);
        $this->setCouleur($couleur);
        $this->setNbSieges($nbSieges);
    } 

    // Pour pouvoir convertir un objet en chaîne de caractères
    public function __toString(): string {
        return "Voiture: " . 
               "Immatriculation - " . $this->getImmatriculation() . ", " .
               "Marque - " . $this->getMarque() . ", " .
               "Couleur - " . $this->getCouleur() . ", " .
               "Nombre de sièges - " . (string)$this->getNbSieges();
    }
    
    public static function construire(array $voitureFormatTableau) : ModelVoiture {
        return new ModelVoiture(
            $voitureFormatTableau['immatriculation'],
            $voitureFormatTableau['marque'],
            $voitureFormatTableau['couleur'],
            intval($voitureFormatTableau['nbSieges']) // Convertir en entier
        );
    }
    
    public static function getVoitures() : array {
        // On récupère l'objet PDO à partir de la classe Model
        require_once 'Model.php';
        
        // On récupère l'objet PDO à partir de la classe Model
        $pdo = Model::getPdo();
        
        // On définit la requête SQL
        $SQL_request = "SELECT * FROM voiture";
        
        // On exécute la requête SQL et on stocke sa réponse dans une variable pdoStatement
        $pdoStatement = $pdo->query($SQL_request);
        
        // On utilise une boucle foreach pour parcourir toutes les entrées de la base de données
        $voitures = [];
        
        foreach($pdoStatement as $voitureFormatTableau){
            $voitures[] = self::construire($voitureFormatTableau);
        }
        
        return $voitures;
    }   

    public static function getVoitureParImmat(string $immatriculation) : ?ModelVoiture {
        // On récupère l'objet PDO à partir de la classe Model
        $pdo = Model::getPdo();
        
        // On définit la requête SQL
        $sql = "SELECT * from voiture WHERE immatriculation = :immatriculationTag";
        $stmt = $pdo->prepare($sql);
        
        // On exécute la requête avec les paramètres
        $stmt->execute(array("immatriculationTag" => $immatriculation));
        
        // On récupère les résultats comme précédemment
        $result = $stmt->fetch();
    
        // Si fetch() renvoie false (pas de voiture correspondante), on renvoie null
        if (!$result) {
            return null;
        }
    
        // Sinon, on construit et renvoie la voiture correspondante
        return static::construire($result);
    }
    
    public function sauvegarder() : void {
        // On récupère l'objet PDO à partir de la classe Model
        $pdo = Model::getPdo();
        
        // On définit la requête SQL
        $sql = "INSERT INTO Voiture (immatriculation, marque, couleur, nbSieges) VALUES (:immatriculation, :marque, :couleur, :nbSieges)";
        
        // On prépare la requête
        $stmt = $pdo->prepare($sql);
        
        // On exécute la requête avec les valeurs de l'objet courant
        $stmt->execute(array(
            'immatriculation' => $this->getImmatriculation(),
            'marque' => $this->getMarque(),
            'couleur' => $this->getCouleur(),
            'nbSieges' => $this->getNbSieges()
        ));
    }

    public function supprimer() : void {
        // On récupère l'objet PDO à partir de la classe Model
        $pdo = Model::getPdo();
        
        // On définit la requête SQL
        $sql = "DELETE FROM Voiture WHERE immatriculation = :immatriculation";
        
        // On prépare la requête
        $stmt = $pdo->prepare($sql);
        
        // On exécute la requête avec les valeurs de l'objet courant
        $stmt->execute(array(
            'immatriculation' => $this->getImmatriculation()
        ));
    }
}