#include <stdio.h>
#include <stdlib.h>

struct cellule {
    int val;
    struct cellule *suivant;
};

typedef struct cellule cell;

// Fonction pour ajouter un élément au début de la liste
void insere_debut(cell **racine, int valeur) {
    cell *nouveau = (cell *)malloc(sizeof(cell));
    if (nouveau == NULL) {
        printf("Allocation de mémoire a échoué.\n");
        return;
    }
    nouveau->val = valeur;
    nouveau->suivant = *racine;
    *racine = nouveau;
}

// Fonction pour afficher tous les éléments de la liste
void afficherListe(cell *racine) {
    printf("Liste : ");
    while (racine != NULL) {
        printf("%d ", racine->val);
        racine = racine->suivant;
    }
    printf("\n");
}

// Fonction pour retourner l'élément à une position donnée (index)
int get(cell *racine, int index) {
    int i = 0;
    while (racine != NULL && i < index) {
        racine = racine->suivant;
        i++;
    }
    if (racine != NULL) {
        return racine->val;
    }
    return -1; // Retourne -1 si l'index est invalide
}

// Fonction pour retourner l'index d'un élément ayant une certaine valeur
int get_index(cell *racine, int valeur) {
    int index = 0;
    while (racine != NULL) {
        if (racine->val == valeur) {
            return index;
        }
        racine = racine->suivant;
        index++;
    }
    return -1; // Retourne -1 si la valeur n'est pas trouvée
}

// Fonction pour ajouter un élément à une position donnée (index)
void ajouter_dans_index(cell **racine, int index, int x) {
    if (index < 0) {
        printf("Index invalide.\n");
        return;
    }

    cell *nouveau = (cell *)malloc(sizeof(cell));
    if (nouveau == NULL) {
        printf("Allocation de mémoire a échoué.\n");
        return;
    }
    nouveau->val = x;

    if (index == 0) {
        nouveau->suivant = *racine;
        *racine = nouveau;
        return;
    }

    cell *temp = *racine;
    int i = 0;
    while (temp != NULL && i < index - 1) {
        temp = temp->suivant;
        i++;
    }

    if (temp == NULL) {
        printf("Index invalide.\n");
        free(nouveau);
        return;
    }

    nouveau->suivant = temp->suivant;
    temp->suivant = nouveau;
}

// Fonction pour ajouter un élément à la fin de la liste
void ajouter_fin(cell **racine, int x) {
    cell *nouveau = (cell *)malloc(sizeof(cell));
    if (nouveau == NULL) {
        printf("Echec de l'ajout.\n");
        return;
    }
    nouveau->val = x;
    nouveau->suivant = NULL;

    if (*racine == NULL) {
        *racine = nouveau;
        return;
    }

    cell *temp = *racine;
    while (temp->suivant != NULL) {
        temp = temp->suivant;
    }
    temp->suivant = nouveau;
}

int main() {
    cell *maListe = NULL; // Déclaration d'un pointeur vers la liste chaînée

    // Ajout d'éléments à la liste en utilisant insere_debut() avec le pointeur maListe
    insere_debut(&maListe, 2);
    insere_debut(&maListe, 20);
    insere_debut(&maListe, 40);

    // Affichage de la liste en utilisant afficherListe() avec le pointeur maListe
    afficherListe(maListe);

    // Utilisation de la fonction get() pour obtenir l'élément à un index spécifique
    printf("Element à index 1 : %d\n", get(maListe, 1));

    // Utilisation de la fonction get_index() pour obtenir l'index d'un élément ayant une valeur spécifique
    printf("Index de la valeur 20 : %d\n", get_index(maListe, 20));

    // Utilisation de la fonction ajouter_dans_index() pour ajouter un élément à un index spécifique
    ajouter_dans_index(&maListe, 2, 10);

    // Utilisation de la fonction ajouter_fin() pour ajouter un élément à la fin de la liste
    ajouter_fin(&maListe, 50);

    // Affichage de ma liste
    afficherListe(maListe);

    return 0;
}
