// Exerice 2:
#include <stdio.h>
#include <stdlib.h>

// Structure pour les cellules de la liste doublement chaînée
struct cellule {
    int val;
    struct cellule *suivant;
    struct cellule *precedent;
};

typedef struct cellule cell;

// Initialisation de la racine de la liste à NULL
cell *racine = NULL;

// Fonction pour ajouter un élément au début de la liste
void ajouter_debut(int valeur) {
    cell *nouveau = (cell *)malloc(sizeof(cell));
    if (nouveau == NULL) {
        printf("Allocation de mémoire a échoué.\n");
        return;
    }
    nouveau->val = valeur;
    nouveau->suivant = racine;
    nouveau->precedent = NULL;

    if (racine != NULL) {
        racine->precedent = nouveau;
    }

    racine = nouveau;
}

// Fonction pour ajouter un élément à la fin de la liste
void ajouter_fin(int valeur) {
    cell *nouveau = (cell *)malloc(sizeof(cell));
    if (nouveau == NULL) {
        printf("Allocation de mémoire a échoué.\n");
        return;
    }
    nouveau->val = valeur;
    nouveau->suivant = NULL;

    if (racine == NULL) {
        nouveau->precedent = NULL;
        racine = nouveau;
        return;
    }

    cell *temp = racine;
    while (temp->suivant != NULL) {
        temp = temp->suivant;
    }

    temp->suivant = nouveau;
    nouveau->precedent = temp;
}

// Fonction pour afficher tous les éléments de la liste
void afficherListe() {
    printf("Liste : ");
    cell *temp = racine;
    while (temp != NULL) {
        printf("%d ", temp->val);
        temp = temp->suivant;
    }
    printf("\n");
}

// Fonction pour récupérer un élément à une position donnée (index)
int get(int index) {
    int i = 0;
    cell *temp = racine;
    while (temp != NULL && i < index) {
        temp = temp->suivant;
        i++;
    }
    if (temp != NULL) {
        return temp->val;
    }
    return -1;
}

// Fonction pour trouver l'index d'un élément donné
int get_index(int valeur) {
    int index = 0;
    cell *temp = racine;
    while (temp != NULL) {
        if (temp->val == valeur) {
            return index;
        }
        temp = temp->suivant;
        index++;
    }
    return -1;
}

// Fonction pour ajouter un élément à une position donnée (index)
void ajouter_dans_index(int index, int x) {
    // code pour ajouter un élément à une position donnée dans la liste
    // (cette fonction est à implémenter)
}

int main() {
    // Ajout d'éléments à la liste
    ajouter_debut(2);
    ajouter_debut(20);
    ajouter_fin(40);

    // Récupération de l'élément à l'index 1
    int elementAtIndex1 = get(1);
    if (elementAtIndex1 != -1) {
        printf("Element à l'index 1 : %d\n", elementAtIndex1);
    } else {
        printf("Index invalide.\n");
    }

    // Affichage de la liste complète
    afficherListe();

    return 0;
}
