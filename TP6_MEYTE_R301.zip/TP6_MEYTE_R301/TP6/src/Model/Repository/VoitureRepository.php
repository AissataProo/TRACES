<?php
namespace App\Covoiturage\Model\Repository;

use App\Covoiturage\Model\Repository\DatabaseConnection;
use App\Covoiturage\Model\DataObject\Voiture;
use PDOException;

class VoitureRepository {
    public static function getVoitures(): array {
        $pdo = DatabaseConnection::getPdo();
        $voitures = [];
        $sql = "SELECT * FROM voiture";
        $pdoStatement = $pdo->query($sql);

        if ($pdoStatement) {
            foreach ($pdoStatement as $voitureFormatTableau) {
                $voitures[] = self::construire($voitureFormatTableau);
            }
        } else {
            throw new PDOException("Impossible d'exécuter la requête !");
        }

        return $voitures;
    }

    public static function getVoitureParImmat(string $immatriculation): ?Voiture {
        $sql = "SELECT * FROM voiture WHERE immatriculation = :immatriculationTag";
        $pdoStatement = DatabaseConnection::getPdo()->prepare($sql);
        $values = [
            "immatriculationTag" => $immatriculation,
        ];

        $pdoStatement->execute($values);
        $voitureFormatTableau = $pdoStatement->fetch();

        if ($voitureFormatTableau === false) {
            return null;
        }

        return static::construire($voitureFormatTableau);
    }

    public static function sauvegarder(Voiture $voiture): void {
        $sql = "INSERT INTO voiture (immatriculation, couleur, marque, nbSieges) VALUES (:immatriculation, :couleur, :marque, :nbSieges)";
        $pdoStatement = DatabaseConnection::getPdo()->prepare($sql);
        $values = [
            ':immatriculation' => $voiture->getImmatriculation(),
            ':couleur' => $voiture->getCouleur(),
            ':marque' => $voiture->getMarque(),
            ':nbSieges' => $voiture->getNbSieges(),
        ];

        if ($pdoStatement->execute($values)) {
            echo "Voiture enregistrée avec succès!";
        } else {
            throw new PDOException("Erreur lors de l'enregistrement de la voiture: " . $pdoStatement->errorInfo()[2]);
        }
    }

    public static function supprimer(Voiture $voiture): void {
        $pdo = DatabaseConnection::getPdo();
        $sql = "DELETE FROM voiture WHERE immatriculation = :immatriculation";
        $pdoStatement = $pdo->prepare($sql);
        $values = [
            'immatriculation' => $voiture->getImmatriculation(),
        ];

        $pdoStatement->execute($values);
    }

    public static function supprimerParImmatriculation(string $immatriculation): string {
        $pdo = DatabaseConnection::getPdo();
        try {
            $sql = "DELETE FROM voiture WHERE imm
