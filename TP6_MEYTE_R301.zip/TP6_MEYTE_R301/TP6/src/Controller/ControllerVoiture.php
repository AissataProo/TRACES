<?php
namespace App\Covoiturage\Controller;
use App\Covoiturage\Model\DataObject\Voiture;
use App\Covoiturage\Model\Repository\VoitureRepository; 

class ControllerVoiture {
    public static function readAll(): void {
        $voitures = Voiture::getVoitures();
        self::afficheVue('voiture/list.php', [
            'pagetitle' => 'Liste des voitures',
            'voitures' => $voitures
        ]);
    }

    public static function read(): void {
        $immat = $_GET['immat'];
        if (Voiture::getVoitureParImmat($immat) == null) {
            self::afficheVue('voiture/error.php', ['immat' => $immat]);
        } else {
            $voiture = Voiture::getVoitureParImmat($immat);
            self::afficheVue('voiture/detail.php', ['voiture' => $voiture]);
        }
    }

    public static function afficheVue(string $cheminVue, array $parametres = []): void {
        extract($parametres);
        require "../src/view/$cheminVue";
    }

    public static function create(): void {
        self::afficheVue('voiture/create.php');
    }

    public static function created(): void {
        // Récupérer les données du formulaire via POST
        $immatriculation = $_POST['immatriculation'];
        $marque = $_POST['marque'];
        $couleur = $_POST['couleur'];
        $nbSieges = $_POST['nbSiege'];

        // Créer une instance de Voiture avec les données reçues
        $voiture = new Voiture($immatriculation, $marque, $couleur, $nbSieges);

        // Appeler la méthode sauvegarder du modèle
        $voiture->sauvegarder();

        // Rediriger vers la liste de toutes les voitures (readAll)
        self::readAll();
    }

    public static function deleteConfirm(): void {
        $immat = $_GET['immat'];
        $voiture = Voiture::getVoitureParImmat($immat);
        self::afficheVue('voiture/deleteConfirm.php', ['voiture' => $voiture]);
    }

    public static function deleted(): void {
        $immat = $_GET['immat'];
        $voiture = Voiture::getVoitureParImmat($immat);
        $voiture->supprimer();
        self::readAll();
    }

    public static function error(string $errorMessage = ""): void {
        $params = ['errorMessage' => $errorMessage];
        self::afficheVue('voiture/error.php', $params);
    }

    public static function verificationAction(string $action): void {
        // Obtenir la liste des méthodes de la classe ControllerVoiture
        $methods = get_class_methods(__CLASS__);

        // Vérifier si l'action spécifiée existe dans la liste des méthodes
        if (in_array($action, $methods)) {
            // Si l'action existe, appeler la méthode de manière dynamique
            call_user_func([__CLASS__, $action]);
        } else {
            // Si l'action n'existe pas, appeler l'action error
            self::error("L'action '$action' n'est pas reconnue, réessayez ");
        }
    }
    public static function delete(): void {
        $immat = $_GET['immat'];
        VoitureRepository::supprimerParImmatriculation($immat);
        $params = ["immatriculation" => $immat];
        self::afficheVue("deleted.php", $params);
        self::readAll();
    }
}
?>
