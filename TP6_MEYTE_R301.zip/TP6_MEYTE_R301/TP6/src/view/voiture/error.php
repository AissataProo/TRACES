<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Erreur</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Erreur</h1>
    <!-- <?php
    // echo '<p> Aucune voiture correspondant à l\'immatriculation ' . htmlspecialchars($immat) . '</p>';
    ?> -->
    <h2>Problème avec la voiture</h2>
    <?php if (!empty($errorMessage)) : ?>
        <p><?php echo htmlspecialchars($errorMessage); ?></p>
    <?php else : ?>
        <p>Problème avec la voiture</p>
    <?php endif; 
    ?>
</body>
</html>
