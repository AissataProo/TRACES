<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Formulaire Voiture</title>
    <link rel="stylesheet" type="text/css" href="/public/css/styles.css">
    <script src="/public/js/scripts.js"></script>
</head>

<body>
    <form method="post" action="/frontController.php?action=updated">
        <fieldset>
            <p>Mon formulaire :</p>

            <p>
                <label for="immat_id">Immatriculation</label> :
                <input type="text" placeholder="4578215A" name="immatriculation" id="immat_id" readonly required
                    value="<?php echo htmlspecialchars($voiture->getImmatriculation()); ?>" />
            </p>
            <p>
                <label for="marque_id">Marque</label> :
                <input type="text" placeholder="Dacia" name="marque" id="marque_id" required
                    value="<?php echo htmlspecialchars($voiture->getMarque()); ?>" />
            </p>
            <p>
                <label for="couleur_id">Couleur</label> :
                <input type="text" placeholder="Noire" name="couleur" id="couleur_id" required
                    value="<?php echo htmlspecialchars($voiture->getCouleur()); ?>" />
            </p>
            <p>
                <label for="nbSiege_id">Nombre de sièges</label> :
                <input type="text" placeholder="5" name="nbSiege" id="nbSiege_id" required
                    value="<?php echo htmlspecialchars($voiture->getNbSieges()); ?>" />
            </p>
            <input type='hidden' name='action' value='updated'>

            <input type="submit" value="Envoyer" name="submit" />
        </fieldset>
    </form>
</body>

</html>
