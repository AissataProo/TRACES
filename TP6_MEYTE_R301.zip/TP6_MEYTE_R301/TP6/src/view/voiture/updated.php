<!DOCTYPE HTML>
<html>

<head>
    <meta charset="utf-8" />
    <title>Opération sur les Voitures</title>
</head>

<body>
    <h1>Opération sur les Voitures</h1>

    <?php if (isset($immatriculationSupprimee)) : ?>
        <h2>Suppression de Voiture</h2>
        <p>La voiture d’immatriculation <?php echo htmlspecialchars($immatriculationSupprimee); ?> a bien été supprimée.</p>
    <?php endif; ?>

    <?php if (count($voitures) > 0) : ?>
        <h2>Liste des voitures mises à jour :</h2>
        <?php foreach ($voitures as $voiture) : ?>
            <p><?php echo htmlspecialchars($voiture->getImmatriculation()); ?> - 
            <?php echo htmlspecialchars($voiture->getMarque()); ?> - 
            <?php echo htmlspecialchars($voiture->getCouleur()); ?> - 
            <?php echo htmlspecialchars($voiture->getNbSieges()); ?> sièges</p>
        <?php endforeach; ?>
    <?php else : ?>
        <p>Aucune voiture à afficher.</p>
    <?php endif; ?>

    <p><a href="../web/frontController.php?action=readAll">Retour à la liste des voitures</a></p>
</body>

</html>
