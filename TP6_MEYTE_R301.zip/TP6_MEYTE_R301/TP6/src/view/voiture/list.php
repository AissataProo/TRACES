<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Liste des voitures</title>
    <style>
        /* Define your CSS styles here */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }

        h1 {
            color: #333;
        }

        p {
            color: #666;
            margin-bottom: 5px;
        }

        .button-container {
            margin-top: 10px;
        }

        input[type="button"] {
            margin-right: 5px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            padding: 5px 10px;
        }

        input[type="button"]:hover {
            background-color: #ff7f00; /* Orange */
        }

        a {
            color: #ff7f00; /* Orange */
            text-decoration: none;
            margin-top: 20px;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h1>Liste des voitures</h1>
    <?php
    foreach ($voitures as $voiture) {
        $immatriculationHTML = htmlspecialchars($voiture->getImmatriculation());
        $immatriculationURL = rawurlencode($voiture->getImmatriculation());
        echo '<p> Voiture avec l\'immatriculation ' . $immatriculationHTML . '</p>';
        echo '<div class="button-container">';
        echo '<input type="button" value="Détail" onclick="window.location.href=\'frontController.php?action=read&immat=' . $immatriculationURL . '\';">';
        echo '<input type="button" value="Supprimer" onclick="window.location.href=\'frontController.php?action=deleteConfirm&immat=' . $immatriculationURL . '\';">';
        echo '</div>';
    }
    ?>
    <a href="frontController.php?action=create">Créer une voiture</a>
</body>
</html>
