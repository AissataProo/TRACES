<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($pagetitle); ?></title>
</head>
<body>
    <header>
        <nav>
            <a href="frontController.php?action=readAll">Liste des voitures</a>
            <a href="frontController.php?action=readAll&controller=utilisateur">Accueil des Utilisateurs</a>
            <a href="frontController.php?action=readAll&controller=trajet">Accueil des trajets</a>
        </nav>
    </header>
    <main>
        <?php require __DIR__ . "/{$cheminVueBody}"; ?>
    </main>
    <footer>
        <p>Site de covoiturage de MEYTE</p>
    </footer>
</body>
</html>
