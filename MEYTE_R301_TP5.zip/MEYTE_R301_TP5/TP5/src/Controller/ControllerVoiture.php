<?php
namespace App\Covoiturage\Controller;
// Récupération du fichier conf.php : 
// insertion de la class Model
use App\Covoiturage\Model\ModelVoiture as ModelVoiture;
class ControllerVoiture{
        public static function readAll() : void{
            $voitures = ModelVoiture::getVoitures();
            self::afficheVue('voiture/list.php', [
                'pagetitle' => 'Liste des voitures',
                'voitures' => $voitures
            ]);
        }
       
        public static function read() : void{
            $immat = $_GET['immat'];
            if (ModelVoiture::getVoitureParImmat($immat) == null) {
                self::afficheVue('voiture/error.php', ['immat' => $immat]);
            }
            else{
                $voitures = ModelVoiture::getVoitureParImmat($immat);
                self::afficheVue('voiture/detail.php', ['voitures' => $voitures]);
            }
        }

        public static function afficheVue(string $cheminVue, array $parametres = []) : void {
            extract($parametres);
            require "../src/view/$cheminVue";
        }

        public static function create() : void{
            self::afficheVue('voiture/create.php');
        }
            
        public static function created() : void {
            // Récupérer les données du formulaire via POST
            $immatriculation = $_POST['immatriculation'];
            $marque = $_POST['marque'];
            $couleur = $_POST['couleur'];
            $nbSieges = $_POST['nbSiege'];
        
            // Créer une instance de ModelVoiture avec les données reçues
            $voiture = new ModelVoiture($immatriculation, $marque, $couleur, $nbSieges);
        
            // Appeler la méthode sauvegarder du modèle
            $voiture->sauvegarder();
        
            // Rediriger vers la liste de toutes les voitures (readAll)
            self::readAll();
        }
        

        public static function deleteConfirm() : void{
            $immat = $_GET['immat'];
            $voiture = ModelVoiture::getVoitureParImmat($immat);
            self::afficheVue('voiture/deleteConfirm.php', ['voitures' => $voiture]);
        }

        public static function deleted() : void{
            $immat = $_GET['immat'];
            $voiture = ModelVoiture::getVoitureParImmat($immat);
            $voiture->supprimer();
            self::readAll();
        }

    }
?>