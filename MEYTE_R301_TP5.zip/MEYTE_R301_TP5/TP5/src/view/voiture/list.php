<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Liste des voitures</title>
</head>
<body>
    <h1>Liste des voitures</h1>
    <?php
    foreach ($voitures as $voiture) {
        $immatriculationHTML = htmlspecialchars($voiture->getImmatriculation());
        $immatriculationURL = rawurlencode($voiture->getImmatriculation());
        echo '<p> Voiture avec l\'immatriculation ' . $immatriculationHTML . '</p>';
        echo '<div class="button-container">';
        echo '<input type="button" value="Détail" onclick="window.location.href=\'frontController.php?action=read&immat=' . $immatriculationURL . '\';">';
        echo '<input type="button" value="Supprimer" onclick="window.location.href=\'frontController.php?action=deleteConfirm&immat=' . $immatriculationURL . '\';">';
        echo '</div>';
    }
    ?>
    <a href="frontController.php?action=create">Créer une voiture</a>
</body>
</html>
