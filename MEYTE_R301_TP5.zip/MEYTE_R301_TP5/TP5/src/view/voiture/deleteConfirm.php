<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8" />
    <title> Pas de retour en arrière </title> 
    <link rel="stylesheet" href="style.css">
</head>
<body>
<form method="get" action="frontController.php?action=deleted">
    <h1> Après suppression, il n'y aura pas de retour en arrière : </h1>
    <h2> Voulez vous vraiment supprimer ?</h2>
    <p> Voiture immatriculée : <?php echo htmlspecialchars($voitures->getImmatriculation()); ?> </p>
        <input type='hidden' name='immat' value='<?php echo htmlspecialchars($voitures->getImmatriculation()); ?>'>
        <input type='hidden' name='action' value='deleted'>
        <p> 
        <input type="submit" value="Supprimer">        
        </p>
    </form>
    <p><a href="frontController.php?action=readAll">Retour à la liste des voitures</a></p>
</body>
</html>

