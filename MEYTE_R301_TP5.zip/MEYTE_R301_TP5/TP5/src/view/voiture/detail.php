<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Détails de la voiture</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Détails de la voiture</h1>
        <p>Immatriculation : <?php echo htmlspecialchars($voitures->getImmatriculation()); ?></p>
        <br>
        <p>Marque : <?php echo htmlspecialchars($voitures->getMarque()); ?></p>
        <br>
        <p>Couleur : <?php echo htmlspecialchars($voitures->getCouleur()); ?></p>
        <br>
        <p>Nombre de sièges : <?php echo htmlspecialchars($voitures->getNbSieges()); ?></p>

        <div class="buttons-container">
            <button class="delete" onclick="window.location.href='frontController.php?action=deleteConfirm&immat=<?php echo rawurlencode($voitures->getImmatriculation()); ?>'">Supprimer</button>
        </div>

        <div class="buttons-container">
            <a class="return" href="frontcontroller.php?action=readAll">Retour à la liste des voitures</a>
        </div>
    </div>
</body>
</html>