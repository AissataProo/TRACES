<?php
namespace App\Covoiturage\Model;
// Récupération du fichier conf.php : 
use App\Covoiturage\config\Conf as Conf;
use \PDO;
use \PDOException;
// require_once __DIR__ . '/../config/Conf.php';
// Création de la classe Model : 
class Model {
    private static $instance = null;
    private $pdo;
    // Conf est un raccourci pour App\Covoiturage\Config\Conf
    

    private function __construct()
    {
        // Récupération des données : 
        $hostname = Conf::getHostname();
        $database = Conf::getDatabase();
        $login =Conf::getLogin();
        $password = Conf::getPassword();
        
        try {
            // Connexion à la base de données 
            // Le dernier argument sert à ce que toutes les chaines de caractères 
            // en entrée et sortie de MySql soit dans le codage UTF-8
            $this->pdo = new PDO("mysql:host=$hostname;dbname=$database",
            $login, $password,
            array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
            // On active le mode d'affichage des erreurs, et le lancement d'exception
            // en cas d'erreur
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Définissez d'autres options PDO si nécessaire.
        } catch (PDOException $e) {
            // Affichant un message d'erreur.
            echo 'Erreur de connexion à la base de données : ' . $e->getMessage();
        }
    }

    public static function getPdo(){
        return static::getInstance()->pdo;
    }

    private static function getInstance(){
        // L'attribut statique $pdo s'obtient avec la syntaxe static::$pdo 
        // au lieu de $this->pdo pour un attribut non statique
        if (is_null(static::$instance)) {
            // Appel du constructeur
            static::$instance = new Model();
        }
        return static::$instance;
    }
}

?>