<?php
use App\Covoiturage\Controller\ControllerVoiture as ControllerVoiture;
require __DIR__ . "/../src/Lib/Psr4AutoloaderClass.php";
// instantiate the loader
$loader = new App\Covoiturage\Lib\Psr4AutoloaderClass();
// register the base directories for the namespace prefix
$loader->addNamespace('App\Covoiturage', __DIR__ . '/../src');
// register the autoloader
$loader->register();
// On récupère l'action passée dans l'URL
$action = isset($_GET['action']) ? $_GET['action'] : 'readAll';
// Appel de la méthode statique $action de ControllerVoiture
ControllerVoiture::$action();
// Appel de la méthode statique $action de ControllerVoiture avec les paramètres pour la vue
if ($action === 'test') {
    require_once __DIR__ . '/../src/view/view.php';
} else {
    ControllerVoiture::$action($pagetitle, $cheminVueBody);
}
?>
