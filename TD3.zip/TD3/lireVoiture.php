<?php
require_once "Model.php";
require_once "Voiture.php";

$pdoStatement = Model::getPdo()->query("SELECT * FROM voiture");
$pdoStatement = Model::getPdo()->query("SELECT DISTINCT * FROM voiture");

while ($voitureFormatTableau = $pdoStatement->fetch()) {
    $voiture = new Voiture(
        $voitureFormatTableau["immatriculation"],
        $voitureFormatTableau["marque"],
        $voitureFormatTableau["couleur"],
        $voitureFormatTableau["nbSieges"]
    );
    echo $voiture->__toString();
    echo "<br>";
}
?>