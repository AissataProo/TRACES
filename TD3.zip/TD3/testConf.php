<?php
 // On inclut les fichiers de classe PHP pour pouvoi
// se servir de la classe Conf. 
 // require_once évite que Conf.php soit inclus plusieurs fois, 
 // et donc que la classe Conf soit déclaré plus d'une fois. 
 require_once 'Conf.php';
 // On affiche le login de la base de donnees
 echo "Compte : " . Conf::getLogin(); 
 echo ' <br>';
 echo "Hostname : " . Conf::getHostname();
 echo ' <br>';
 echo "Base de donnée : " . Conf::getDatabase();
 echo '<br>';
 echo "Le mot de passe  : " . Conf::getPassword() //rien ne s'affiche car je n'ai pas de mot de passe
?>