<?php
require_once 'Conf.php';
class Model {
    private $pdo; 
    private static $instance=null;
    public static function getPdo() {
    return static::getInstance()->pdo;
        }
    
    // un constructeur
    public function __construct(){
    $hostname = conf::getHostname();
    $login = conf::getLogin();
    $password= conf::getPassword();
    $databaseName = conf::getDatabase();
    $this->pdo = new PDO("mysql:host=$hostname;dbname=$databaseName",
    $login, $password,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
    $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

}
    private static function getInstance() {
        // L'attribut statique $pdo s'obtient avec la syntaxe static::$pdo 
        // au lieu de $this->pdo pour un attribut non statique
        if (is_null(static::$instance)){
        // Appel du constructeur
        static::$instance = new Model();
        }
        return static::$instance;
        }
    }  
?>