<?php
    // Inclure les fichiers : 
    require_once 'Trajets.php';
    require_once 'Utilisateurs.php';

    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        // Récupération des données du formulaire
    $login=$_GET["login"];
    }

    // Appel de la fonction getPassagers : 
    $passagers = Trajets::getPassagers($id);

    // Affichage : 

    foreach ($passagers as $passager){
        echo"Login : ".$passager->login ."<br>";
        echo "Nom : " . $passager->nom . "<br>";
        echo "Prénom : " . $passager->Prénom . "<br>";
        echo "<br>";
}
?>