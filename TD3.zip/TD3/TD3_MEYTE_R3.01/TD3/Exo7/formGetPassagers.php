<!DOCTYPE html>
    <html>
        <head>
            <meta charset="utf-8" />
            <title> Recherche Utilisateurs : </title>
        </head>
        <body>
            <!--Création d'un formulaire : -->
            <form method="GET" action="testGetPassagers.php">
                <fieldset>
                    <legend>Formulaire :</legend>
                    <!--Création des champs à remplir : -->
                    <p>
                        <label> Entrez l'id du trajet : </label>
                        <input type="text" name="id" id=$id required>
                    </p>	
                    <p>
                        <input type="submit" value="Rechercher">
                    </p>
                </fieldset>
            </form>
        </body>
    </html>
