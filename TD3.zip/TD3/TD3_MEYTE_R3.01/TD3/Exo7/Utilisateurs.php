<?php
    // Inclure class Model : 
    require_once '../Exo1/Model.php';
    // Class utilisateur : 
    class Utilisateurs {
        // Attributs : 
        public string $login;
        public string $nom;
        public string $Prénom;

        // Constructeur : 
        public function __construct(string $login, string $nom, string $Prénom) {
            $this->login = $login;
            $this->nom = $nom;
            $this->Prénom = $Prénom;
        }

        // getUtilisateurs : 
        public static function getUtilisateurs() {
            $pdo = Model::getPdo();
            $utilisateurs = [];
    
            // Requête SQL pour récupérer tous les utilisateurs
            $sql = "SELECT * FROM Utilisateurs";
            $pdoStatement = $pdo->query($sql);
    
            // Vérification : 
            if ($pdoStatement) {
                foreach ($pdoStatement as $utilisateurFormatTableau) {
                    // Créer un tableau associatif pour chaque utilisateur
                    $utilisateurs[] = $utilisateurFormatTableau;
                }
            } else {
                echo "Erreur lors de la récupération des utilisateurs : " . $pdo->errorInfo()[2];
            }
    
            return $utilisateurs;

        }
    }
?>