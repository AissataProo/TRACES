<?php
// Inclure les fichiers requis
require_once '../Exo7/Trajets.php';
require_once 'Utilisateurs.php';

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Récupération des données du formulaire
    $login = $_GET["login"];
}

// Appel de la fonction getTrajets :
$Trajets = Utilisateurs::getTrajets($login);

// Affichage :
foreach ($Trajets as $trajet) {
    echo "Voici les trajets auxquels l'utilisateur $login est inscrit en tant que passager :<br>";
    echo "<br>";
    echo "ID : " . $trajet['Id'] . "<br>";
    echo "Départ : " . $trajet['Départ'] . "<br>";
    echo "Arrivé : " . $trajet['Arrivé'] . "<br>";
    echo "Date de covoiturage : " . $trajet['Date_co'] . "<br>";
    echo "Nombre de places : " . $trajet['Nb_Places'] . "<br>";
    echo "Prix : " . $trajet['Prix'] . "<br>";
    echo "<br>";
}
?>
