<?php

// Inclure le fichier Model.php : 
require_once "Model.php";
require_once "Voiture.php";

$immatV = "BP954NG";

// // Appel de la fonction : 
// $voiture = Voiture::getVoitureParImmat($immatV);

// if($voiture !== null){
//     echo "Trouvée ! <br>" ;
//     echo "$voiture";
// }else {
//     echo "Pas trouvée :(";
// }

// Tester la fonction sauvegarder():

// Nouvelle instance :
$voiture = new Voiture ("5NG","blanc","Ferrari",5);

// Appel de la fonction : 
$voiture->sauvegarder()

?>