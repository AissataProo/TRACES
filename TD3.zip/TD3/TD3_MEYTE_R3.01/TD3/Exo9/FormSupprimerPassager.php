<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Suppression d'un passager : </title>
    </head>
    <body>
        <!-- Création d'un formulaire : -->
        <form method="GET" action="testSupprimerPassager.php">
            <fieldset>
                <legend>Formulaire :</legend>
                <!-- Création des champs à remplir : -->
                <p>
                    <label>Entrez le login de l'utilisateur :</label>
                    <input type="text" name="login" id="passagerLogin" required>
                </p>
                <p>
                    <label> Entrez l'Id du trajet : </label>
                    <input type="text" name="trajetID" id="trajetID" required>
                </p>
                <p>
                    <input type="submit" value="Rechercher">
                </p>
            </fieldset>
        </form>
    </body>
</html>
