<?php
    // Inclure fichier Model :
    require_once "../Exo1/Model.php";

    // Class Trajets :
    class Trajets{
        // Attributs :
        private INT $Id;
        private string $Départ;
        private string $Arrivé;
        private $Date_co;
        private INT $Nb_Places;
        private INT $Prix;
        private String $ConducteurLogin;

        // Constructeur : 
        public function __construct(INT $Id, string $Départ, string $Arrivé, $Date_co, INT $Nb_Places, INT $Prix,String $ConducteurLogin) {
            $this->ID = $Id;
            $this->Départ = $Départ;
            $this->Arrivé = $Arrivé;
            $this->Date_co = $Date_co;
            $this->Nb_Places = $Nb_Places;
            $this->Prix = $Prix;
            $this->ConducteurLogin = $ConducteurLogin;
        }

        // getTrajets() : 
        public static function getTrajets() {
            $pdo = Model::getPdo();
            $trajets = [];
    
            // Requête SQL pour récupérer tous les trajets
            $sql = "SELECT * FROM Trajets";
            $pdoStatement = $pdo->query($sql);
    
            // Vérification : 
            if ($pdoStatement) {
                foreach ($pdoStatement as $trajetFormatTableau) {
                    // Créer un tableau associatif pour chaque trajet
                    $trajets[] = $trajetFormatTableau;
                }
            } else {
                echo "Erreur lors de la récupération des trajets : " . $pdo->errorInfo()[2];
            }
    
            return $trajets;
        }

        // getPassagers() : 
        public static function getPassagers($Id) {
            require_once "Utilisateurs.php"; 
            $pdo = Model::getPdo(); 
        
            // requête SQL : 
            $sql = "SELECT U.* FROM Utilisateurs U 
                    INNER JOIN Passagers P ON U.login = P.passagerLogin
                    WHERE P.TrajetID = :Id";
        
            // Préparer la requête : 
            $pdostatement = $pdo->prepare($sql);
            $pdostatement->bindParam(':Id', $Id, PDO::PARAM_INT);
            $pdostatement->execute();
        
            // Tableau : 
            $passagers = [];
        
            // boucle while pour stocker : 
            while ($row = $pdostatement->fetch(PDO::FETCH_ASSOC)) {
                $passager = new Utilisateurs(
                    $row['login'],
                    $row['nom'],
                    $row['Prénom']
                );
                $passagers[] = $passager;
            }
        
            return $passagers;
        }

        public static function supprimerPassager($trajetId, $passagerLogin) {
            $pdo = Model::getPdo();
            // Vérifier si l'utilisateur est un passager du trajet avant de le supprimer
            $sql = "SELECT * FROM Passagers WHERE trajetID = :trajetId AND passagerLogin = :passagerLogin";
            $pdoStatement = $pdo->prepare($sql);
            // Lier les attributs :
            $pdoStatement->bindParam(':trajetId', $trajetId, PDO::PARAM_INT);
            $pdoStatement->bindParam(':passagerLogin', $passagerLogin, PDO::PARAM_STR);
            // Exécution :
            $pdoStatement->execute();
            // Récupérer les données :
            $passager = $pdoStatement->fetch(PDO::FETCH_ASSOC);
        
            if ($passager !== false) {
                // Supprimer le passager du trajet
                $sql = "DELETE FROM Passagers WHERE TrajetID = :trajetId AND passagerLogin = :passagerLogin";
                $pdoStatement = $pdo->prepare($sql);
                $pdoStatement->bindParam(':trajetId', $trajetId, PDO::PARAM_INT);
                $pdoStatement->bindParam(':passagerLogin', $passagerLogin, PDO::PARAM_STR);
        
                if ($pdoStatement->execute()) {
                    // Vérifier le nombre de lignes supprimées
                    if ($pdoStatement->rowCount() > 0) {
                        return true; // La suppression a réussi
                    } else {
                        return false; // Aucune ligne n'a été supprimée 
                    }
                } else {
                    return false; // Erreur lors de la suppression
                }
            } else {
                return false; // Le passager n'était pas inscrit au trajet
            }
        }
        
        }
        
        


    }
?>