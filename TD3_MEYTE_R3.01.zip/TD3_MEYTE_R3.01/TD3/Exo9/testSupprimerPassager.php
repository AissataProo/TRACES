<?php
// Inclure le fichier Model :
require_once "../Exo1/Model.php";
require_once "Trajets.php"; // Inclure la classe Trajets

// Vérifier si les paramètres nécessaires sont présents dans la requête GET
if (isset($_GET['trajetID']) && isset($_GET['login'])) {
    $trajetId = $_GET['trajetID'];
    $passagerLogin = $_GET['login'];

    // Appeler la méthode supprimerPassager de la classe Trajets
    $result = Trajets::supprimerPassager($trajetId, $passagerLogin);

    if ($result) {
        echo "Passager supprimé avec succès du trajet.";
    } else {
        echo "Erreur lors de la suppression du passager du trajet.";
    }
}
?>