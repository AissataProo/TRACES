<?php
// Inclure model :
require_once "Model.php";
// Création de la class Voiture : 
class Voiture {
    
    public string $immatriculation;
    public string $couleur;
    public string $marque;
    public int $nbSieges;

    // Constructeur : 
    public function __construct($immatriculation, $couleur, $marque, $nbSieges){
        $this->immatriculation = $immatriculation;
        $this->couleur = $couleur;
        $this->marque = $marque;
        $this->nbSieges = $nbSieges;
    }

    // Affichage : 
    public function __toString(){
        return "Immatriculation : " . $this->immatriculation . "<br> Couleur : " . $this->couleur . "<br> Marque : " . $this->marque . "<br> Nombre de sièges : " . $this->nbSieges . "<br>";
    }

    public static function construire(array $voitureFormatTableau): Voiture {
        return new Voiture(
            $voitureFormatTableau["immatriculation"],
            $voitureFormatTableau["couleur"],
            $voitureFormatTableau["marque"],
            $voitureFormatTableau["nbSieges"]
        );
    }

    public static function getVoitures(){
        $pdo = Model::getPdo();
        $voitures = [];

        // Requête SQL : 
        $sql = "SELECT * FROM voiture";
        $pdoStatement = $pdo->query($sql); // Utilisation de query

        // Vérification : 
        if ($pdoStatement) {
            echo "Requête réussie ! <br>";
            echo "<br>";

            foreach ($pdoStatement as $voitureFormatTableau) {
                // Créer une instance $voiture pour chaque ligne de résultat
                $voiture = new Voiture(
                    $voitureFormatTableau["immatriculation"],
                    $voitureFormatTableau["couleur"],
                    $voitureFormatTableau["marque"],
                    $voitureFormatTableau["nbSieges"]
                );

                $voitures[] = $voiture;
            }
        } else {
            echo "Erreur" . $pdo->errorInfo()[2];
        }
        
        return $voitures;
    }

    public static function getVoitureParImmat(string $immatriculation) : ?Voiture {
        $sql = "SELECT * from voiture WHERE immatriculation = :immatriculationTag";
        // Préparation de la requête
        $pdoStatement = Model::getPdo()->prepare($sql);
        $values = array(
            "immatriculationTag" => $immatriculation,
            //nomdutag => valeur, ...
        );
        // On donne les valeurs et on exécute la requête
        $pdoStatement->execute($values);
        // On récupère les résultats comme précédemment
        // Note: fetch() renvoie false si pas de voiture correspondante
        $voiture = $pdoStatement->fetch();

        // Renvoie null si aucune voiture trouvée : 
        if ($voiture == false){
            return null;
        }

        return static::construire($voiture);
    }

    public function sauvegarder(): void {
        $sql = "INSERT INTO voiture (immatriculation, couleur, marque, nbSieges) VALUES (:immatriculation, :couleur, :marque, :nbSieges)";
    
        // Préparation de la requête :
        $pdoStatement = Model::getPdo()->prepare($sql);
    
        // Liaison des paramètres :
        $pdoStatement->bindParam(':immatriculation', $this->immatriculation, PDO::PARAM_STR);
        $pdoStatement->bindParam(':couleur', $this->couleur, PDO::PARAM_STR);
        $pdoStatement->bindParam(':marque', $this->marque, PDO::PARAM_STR);
        $pdoStatement->bindParam(':nbSieges', $this->nbSieges, PDO::PARAM_INT);
    
        // Exécution de la requête :
        if ($pdoStatement->execute()) {
            echo "Voiture enregistrée avec succès !";
        } else {
            echo "Erreur lors de l'enregistrement de la voiture : " . $pdoStatement->errorInfo()[2];
        }
    }
}
?>
