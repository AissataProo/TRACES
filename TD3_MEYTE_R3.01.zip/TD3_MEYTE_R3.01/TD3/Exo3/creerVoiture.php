<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Résultat du formulaire</title>
</head>
    <body>
            <?php
                // Vérification si le formulaire a été soumis
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    // Récupération des données du formulaire
                    $immatriculation = $_POST["immatriculation"];
                    $marque = $_POST["marque"];
                    $couleur = $_POST["couleur"];
                    $nbSieges = $_POST["nbSieges"];
                    
                    // Sauvegarde des résultats : 
                    require_once "../Exo1/Voiture.php";
                    $voiture = new Voiture($immatriculation,$marque,$couleur,$nbSieges);
                    $voiture -> sauvegarder();

                } else {
                    echo "Le formulaire n'a pas été soumis.";
                }
            ?>

    </body>
</html>
