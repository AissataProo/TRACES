<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Recherche Trajets : </title>
    </head>
    <body>
        <!-- Création d'un formulaire : -->
        <form method="GET" action="testGetTrajets.php">
            <fieldset>
                <legend>Formulaire :</legend>
                <!-- Création des champs à remplir : -->
                <p>
                    <label>Entrez le login de l'utilisateur :</label>
                    <input type="text" name="login" id="login" required>
                </p>
                <p>
                    <input type="submit" value="Rechercher">
                </p>
            </fieldset>
        </form>
    </body>
</html>
